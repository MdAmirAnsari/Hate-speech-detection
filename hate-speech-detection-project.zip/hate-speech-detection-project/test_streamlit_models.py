#!/usr/bin/env python3
"""
Test script to verify model loading for Streamlit app
"""

import pickle
import os

def test_model_loading():
    print("Testing model loading...")
    
    # Check if models directory exists
    if not os.path.exists('models'):
        print("❌ Models directory not found!")
        return False
    
    # Check each model file
    tasks = ['task_1', 'task_2', 'task_3']
    models = {}
    
    for task in tasks:
        model_path = f'models/best_model_{task}.pkl'
        
        if not os.path.exists(model_path):
            print(f"❌ Model file {model_path} not found!")
            return False
        
        try:
            with open(model_path, 'rb') as f:
                model_data = pickle.load(f)
            
            print(f"✅ {task} model loaded successfully!")
            print(f"   - Model type: {type(model_data.get('model', 'Not found'))}")
            print(f"   - Vectorizer type: {type(model_data.get('vectorizer', 'Not found'))}")
            print(f"   - Labels: {model_data.get('labels', 'Not found')}")
            
            models[task] = model_data
            
        except Exception as e:
            print(f"❌ Error loading {task} model: {e}")
            return False
    
    print(f"\n🎉 All {len(models)} models loaded successfully!")
    return True

if __name__ == "__main__":
    success = test_model_loading()
    if success:
        print("\n✅ Models are ready for Streamlit app!")
    else:
        print("\n❌ Model loading failed!")
