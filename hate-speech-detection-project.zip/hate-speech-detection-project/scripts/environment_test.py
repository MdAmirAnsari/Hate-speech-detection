#!/usr/bin/env python3
"""
Environment Test Script for Hate Speech Detection Project
This script verifies that all required packages and data are properly installed.
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

def main():
    print("=" * 60)
    print("HATE SPEECH DETECTION ENVIRONMENT TEST")
    print("=" * 60)
    
    # Test 1: Package imports
    print("\n1. Testing package imports...")
    try:
        print("   ✓ pandas, numpy, scikit-learn imported successfully")
        print("   ✓ matplotlib, seaborn imported successfully")
        print("   ✓ nltk imported successfully")
        print("   All packages imported successfully!")
    except Exception as e:
        print(f"   ✗ Error importing packages: {e}")
        return
    
    # Test 2: NLTK data
    print("\n2. Testing NLTK data...")
    try:
        test_text = "This is a test sentence for checking NLTK functionality."
        tokens = word_tokenize(test_text)
        stop_words = set(stopwords.words('english'))
        filtered_tokens = [word for word in tokens if word.lower() not in stop_words and word.isalpha()]
        print(f"   ✓ Tokenization working: {len(tokens)} tokens")
        print(f"   ✓ Stopwords available: {len(stop_words)} English stopwords")
        print(f"   ✓ Filtering working: {len(filtered_tokens)} filtered tokens")
    except Exception as e:
        print(f"   ✗ Error with NLTK: {e}")
        return
    
    # Test 3: Dataset loading
    print("\n3. Testing dataset loading...")
    try:
        df = pd.read_csv('C:\\Users\\user\\Downloads\\english_dataset.tsv', sep='\t')
        print(f"   ✓ Dataset loaded successfully: {df.shape[0]} rows, {df.shape[1]} columns")
        print(f"   ✓ Columns: {df.columns.tolist()}")
        
        # Show label distribution
        print(f"   ✓ Task 1 distribution: {dict(df['task_1'].value_counts())}")
        print(f"   ✓ Task 2 distribution: {dict(df['task_2'].value_counts())}")
        
    except Exception as e:
        print(f"   ✗ Error loading dataset: {e}")
        return
    
    # Test 4: Quick ML pipeline test
    print("\n4. Testing machine learning pipeline...")
    try:
        # Simple test with a small sample
        sample_df = df.sample(100, random_state=42)
        X = sample_df['text']
        y = sample_df['task_1']
        
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        vectorizer = TfidfVectorizer(max_features=100, stop_words='english')
        X_train_tfidf = vectorizer.fit_transform(X_train)
        X_test_tfidf = vectorizer.transform(X_test)
        
        model = LogisticRegression(random_state=42)
        model.fit(X_train_tfidf, y_train)
        
        accuracy = model.score(X_test_tfidf, y_test)
        print(f"   ✓ ML pipeline working: {accuracy:.2f} accuracy on test sample")
        
    except Exception as e:
        print(f"   ✗ Error with ML pipeline: {e}")
        return
    
    print("\n" + "=" * 60)
    print("🎉 ALL TESTS PASSED! Environment is ready for hate speech detection!")
    print("=" * 60)
    
    print("\nNext steps:")
    print("1. Data preprocessing (text cleaning, tokenization)")
    print("2. Feature extraction (TF-IDF, word embeddings)")
    print("3. Model training (Logistic Regression, SVM, Neural Networks)")
    print("4. Model evaluation and fine-tuning")
    print("5. Testing on different tasks (task_1, task_2, task_3)")

if __name__ == "__main__":
    main()
